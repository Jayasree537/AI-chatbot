"""
ChatterBot is a machine learning, conversational dialog engine.
"""
from .chatterbot import ChatBot


__all__ = (
    'ChatBot',
)
